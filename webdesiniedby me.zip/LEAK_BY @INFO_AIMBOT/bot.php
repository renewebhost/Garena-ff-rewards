<?php

$token = "8074014006:AAEbrFL_I0EZOMqkGq7K1rEWOtbYzzscWnI";
$data = [
    'text' => $msg,
    'chat_id' => '5746933924'
];

?>